// All of the Node.js APIs are available in the preload process.
// It has the same sandbox as a Chrome extension.
// This file is used to securely expose a limited set of Node.js APIs
// to the renderer process, but for this application, no APIs are needed.
